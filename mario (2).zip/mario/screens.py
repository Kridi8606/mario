import pygame


def menu(self):
    self.screen.blit(self.sprites['fon'], (0, 0))
    pygame.display.flip()
    running = True
    message = 'game'
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False     
                message = 'end'
            if event.type == pygame.MOUSEBUTTONDOWN:                    
                if event.button == 1:
                    message = 'game'
                    running = False
    return message
                    
                    
def level(self):
    fps = 60
    clock = pygame.time.Clock()
    message = 'end'
    running = True
    while running:  
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                message = 'end'
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_w:
                    coords = (0, -1)
                elif event.key == pygame.K_a:
                    coords = (-1, 0)
                elif event.key == pygame.K_s:
                    coords = (0, 1)
                elif event.key == pygame.K_d:
                    coords = (1, 0)
                if self.player.coords[0] + coords[0] > -1 and self.player.coords[0] + coords[0] < len(self.level_map[0]):
                    if self.player.coords[1] + coords[1] > -1 and self.player.coords[1] + coords[1] < len(self.level_map):
                        if self.level_map[self.player.coords[0] + coords[0]][self.player.coords[1] + coords[1]] != 1:
                            self.player.move(coords)
        
        for y in range(self.camera.coords[0] - 5, self.camera.coords[0] + 6):
            for x in range(self.camera.coords[1] - 5, self.camera.coords[1] + 6):
                if self.level_map[y][x] == 0:
                    self.screen.blit(self.sprites['grass'], (x * self.cell_size, y * self.cell_size))
                if self.level_map[y][x] == 1:
                    self.screen.blit(self.sprites['box'], (x * self.cell_size, y * self.cell_size))
                self.screen.blit(self.sprites['mar'], (self.player.coords[0] * self.cell_size, self.player.coords[1] * self.cell_size))
        pygame.display.flip()
    return message