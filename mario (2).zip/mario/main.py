import pygame
from screens import menu, level


class Player:
    def __init__(self, coords):
        self.coords = coords
        
    def move(self, coords):
        self.coords = (self.coords[0] + coords[0], self.coords[1] + coords[1])
        
        
class Camera:
    def __init__(self, coords):
        self.coords = coords
        

class Game:
    def __init__(self):
        self.sprites = {}
        self.sprites['box'] = pygame.image.load('box.png').convert()
        self.sprites['mar'] = pygame.image.load('mar.png').convert()
        self.sprites['mar'].set_colorkey((0, 0, 0))
        self.sprites['grass'] = pygame.image.load('grass.png').convert()
        self.sprites['fon'] = pygame.image.load('fon.jpg').convert()
        self.screen = screen
        self.cell_size = 50
    
    def start(self, file):
        self.file = file
        self.player = Player((0, 0))
        self.camera = Camera((4, 4))
        self.create_map()
        self.main_loop()
        
    def main_loop(self):
        running = True
        message = 'menu'
        while running:
            if message == 'menu':
                message = menu(self)
            elif message == 'game':
                message = level(self)
            elif message == 'end':
                running = False
        pygame.quit()
            
    def create_map(self):
        try:
            with open(self.file, 'r') as f:
                lines = f.readlines()
        except:
            pygame.quit()
            raise FileNotFoundError()
        level_map = []
        x = -1
        y = -1
        for i in lines:
            if x == -1:
                y += 1
            i = i.strip()
            if '@' in i and x == -1:
                x = i.index('@')
            level_map.append(list(map(int, i.replace('.', '0').replace('#', '1').replace('@', '0'))))
        self.level_map = level_map[:]
        self.player.coords = (x, y)


if __name__ == '__main__':
    pygame.init()
    size = width, height = 500, 500
    file = input()
    screen = pygame.display.set_mode(size)
    game = Game()
    game.start(file)