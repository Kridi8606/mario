import pygame


def menu(self):
    self.screen.blit(self.sprites['fon'], (0, 0))
    pygame.display.flip()
    running = True
    message = 'game'
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False     
                message = 'end'
            if event.type == pygame.MOUSEBUTTONDOWN:                    
                if event.button == 1:
                    message = 'game'
                    running = False
    return message
                    
                    
def level(self):
    fps = 60
    clock = pygame.time.Clock()
    message = 'end'
    running = True
    while running:  
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
                message = 'end'
            if event.type == pygame.KEYDOWN:
                coords = (0, 0)
                if event.key == pygame.K_w:
                    coords = (0, -1)
                elif event.key == pygame.K_a:
                    coords = (-1, 0)
                elif event.key == pygame.K_s:
                    coords = (0, 1)
                elif event.key == pygame.K_d:
                    coords = (1, 0)
                self.player.move(coords)
                if self.player.coords[1] < 0:
                    self.player.coords = (self.player.coords[0], self.player.coords[1] + len(self.level_map[0]))
                if self.player.coords[1] >= len(self.level_map):
                    self.player.coords = (self.player.coords[0], self.player.coords[1] - len(self.level_map[0]))
                if self.player.coords[0] < 0:
                    self.player.coords = (self.player.coords[0] + len(self.level_map[0]), self.player.coords[1])
                if self.player.coords[0] >= len(self.level_map[0]):
                    self.player.coords = (self.player.coords[0] - len(self.level_map[0]), self.player.coords[1])
                if self.level_map[self.player.coords[1]][self.player.coords[0]] == 1:
                    self.player.move((coords[0] * -1, coords[1] * -1))
                self.camera.coords = self.player.coords[:]    
                    
        self.screen.fill('black')
        i = -1
        j = -1
        for y in range(self.camera.coords[1] - 4, self.camera.coords[1] + 7):
            for x in range(self.camera.coords[0] - 4, self.camera.coords[0] + 7):
                try:
                    if y < 0:
                        y += len(self.level_map)
                    if y >= len(self.level_map):
                        y -= len(self.level_map)
                    if x < 0:
                        x += len(self.level_map[0])
                    if x >= len(self.level_map[0]):
                        x -= len(self.level_map[0])
                    if self.level_map[y][x] == 0:
                        self.screen.blit(self.sprites['grass'], (i * self.cell_size, j * self.cell_size))
                    elif self.level_map[y][x] == 1:
                        self.screen.blit(self.sprites['box'], (i * self.cell_size, j * self.cell_size))
                except:
                    pass
                i += 1
            j += 1
            i = 0
        self.screen.blit(self.sprites['mar'], (4 * self.cell_size, 3 * self.cell_size))
        pygame.display.flip()
    return message